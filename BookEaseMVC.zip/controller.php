<?php
namespace App\Controllers;

use App\Models\Appointment;
use App\Models\Client;
use App\Models\Service;
use App\Models\Staff;

class AppointmentsController extends Controller {
    
    public function index() {
        $appointments = Appointment::allWithRelations();
        $clients = Client::all();
        $services = Service::all();
        $staff = Staff::all();
        
        $this->render('appointments/index', [
            'appointments' => $appointments,
            'clients' => $clients,
            'services' => $services,
            'staff' => $staff
        ]);
    }

    public function store() {
        $data = $_POST;
        if (Appointment::create($data)) {
            flash('success', 'Appointment created successfully');
        } else {
            flash('error', 'Failed to create appointment');
        }
        redirect('/appointments');
    }
}