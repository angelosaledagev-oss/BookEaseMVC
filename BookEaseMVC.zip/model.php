<?php
namespace App\Models;

class Appointment extends Model {
    
    protected $table = 'appointments';
    
    public static function allWithRelations() {
        $db = getDB();
        $stmt = $db->query("
            SELECT a.*, c.name as client_name, 
                   s.service_name, st.name as staff_name 
            FROM appointments a
            LEFT JOIN clients c ON a.client_id = c.id
            LEFT JOIN services s ON a.service_id = s.id
            LEFT JOIN staff st ON a.staff_id = st.id
            ORDER BY a.schedule DESC
        ");
        return $stmt->fetchAll();
    }
}